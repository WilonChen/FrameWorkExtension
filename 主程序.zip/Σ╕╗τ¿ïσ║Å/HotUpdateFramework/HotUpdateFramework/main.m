//
//  main.m
//  HotUpdateFramework
//
//  Created by 王飞 on 16/4/17.
//  Copyright © 2016年 com.cube.cocoa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
